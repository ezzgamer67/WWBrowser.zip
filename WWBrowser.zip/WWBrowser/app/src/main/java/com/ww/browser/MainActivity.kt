package com.ww.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var loadBar: ProgressBar
    private lateinit var root: FrameLayout
    private lateinit var main: LinearLayout
    private lateinit var desktopBtn: Button
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var desktop = false

    private val home = "https://www.google.com"
    private val desktopUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val mobileUA by lazy { WebSettings.getDefaultUserAgent(this) }
    private val prefs by lazy { getSharedPreferences("ww", MODE_PRIVATE) }

    private val bg = Color.parseColor("#0B1D22")
    private val panel = Color.parseColor("#14343B")
    private val accent = Color.parseColor("#3DD9B4")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        root = FrameLayout(this).apply { setBackgroundColor(bg) }
        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Top bar: back, forward, reload, address box
        val top = LinearLayout(this).apply {
            setBackgroundColor(panel)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        top.addView(btn("‹") { if (web.canGoBack()) web.goBack() })
        top.addView(btn("›") { if (web.canGoForward()) web.goForward() })
        top.addView(btn("⟳") { web.reload() })
        urlBox = EditText(this).apply {
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#8FB0B0"))
            hint = "Search or type a link"
            textSize = 16f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_GO) { go(text.toString()); hideKeyboard(); true } else false
            }
        }
        top.addView(urlBox, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        main.addView(top, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        loadBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        main.addView(loadBar, LinearLayout.LayoutParams(MATCH_PARENT, dp(3)))

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    val u = r.url
                    if (u.scheme == "http" || u.scheme == "https") return false
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                    return true
                }
                override fun onPageStarted(v: WebView, u: String, f: android.graphics.Bitmap?) { urlBox.setText(u) }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(v: WebView, p: Int) {
                    loadBar.progress = p
                    loadBar.visibility = if (p in 1..99) View.VISIBLE else View.GONE
                }
                override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                    customView = view; customCb = cb
                    main.visibility = View.GONE
                    root.addView(view, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
                }
                override fun onHideCustomView() {
                    customView?.let { root.removeView(it) }
                    customView = null; customCb?.onCustomViewHidden()
                    main.visibility = View.VISIBLE
                }
            }
        }
        main.addView(web, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // Bottom quick bar: big buttons for the car
        val bar = LinearLayout(this).apply {
            setBackgroundColor(panel)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        bar.addView(btn("YouTube", 1f) { web.loadUrl("https://m.youtube.com") })
        bar.addView(btn("Google", 1f) { web.loadUrl(home) })
        bar.addView(btn("Netflix", 1f) { openNetflix() })
        bar.addView(btn("★", 0.6f) { bookmarks() })
        desktopBtn = btn("Desktop", 1f) { toggleDesktop() }
        bar.addView(desktopBtn)
        main.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(main, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)

        if (savedInstanceState == null) web.loadUrl(home) else web.restoreState(savedInstanceState)
    }

    private fun btn(label: String, weight: Float = 0f, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.TRANSPARENT)
        minWidth = dp(44)
        minimumWidth = dp(44)
        minHeight = dp(52)
        minimumHeight = dp(52)
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(if (weight > 0f) 0 else WRAP_CONTENT, WRAP_CONTENT, weight)
    }

    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val target = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(target)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBox.windowToken, 0)
        web.requestFocus()
    }

    // Netflix cannot run inside a WebView (DRM), so open the official app or the website.
    private fun openNetflix() {
        val app = packageManager.getLaunchIntentForPackage("com.netflix.mediaclient")
        startActivity(app ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.netflix.com")))
    }

    private fun toggleDesktop() {
        desktop = !desktop
        web.settings.userAgentString = if (desktop) desktopUA else mobileUA
        web.settings.useWideViewPort = desktop
        web.settings.loadWithOverviewMode = desktop
        desktopBtn.setTextColor(if (desktop) accent else Color.WHITE)
        web.reload()
    }

    private fun bookmarks() {
        val list = (prefs.getStringSet("bm", emptySet()) ?: emptySet()).toList().sorted()
        val items = (listOf("＋ Add this page") + list).toTypedArray()
        val dialog = AlertDialog.Builder(this)
            .setTitle("Bookmarks (hold to remove)")
            .setItems(items) { _, i ->
                if (i == 0) {
                    val u = web.url
                    if (u != null) prefs.edit().putStringSet("bm", (list + u).toSet()).apply()
                } else web.loadUrl(list[i - 1])
            }.create()
        dialog.show()
        dialog.listView.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos > 0) {
                prefs.edit().putStringSet("bm", (list - list[pos - 1]).toSet()).apply()
                dialog.dismiss()
            }
            true
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); web.saveState(outState) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
}
